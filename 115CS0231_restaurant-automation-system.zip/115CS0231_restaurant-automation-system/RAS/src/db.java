/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Akankshya
 */
import java.sql.*;

public class db {
    private Connection con;
    private Statement st;
    private ResultSet rs;
    private PreparedStatement ps;
    
    public void conn()
    {
        try{
    
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rats","root","");
        ps=con.prepareStatement("INSERT INTO item VALUES(?,?,?)");
        //rs=st.executeQuery("SELECT * FROM item");
        ps.setString(1,"Chicken Biryani");
        ps.setString(2, "200");
        ps.setString(3,"20");
        ps.executeUpdate();
        /*System.out.println(rs);
        while(rs.next())
        {  String name;
           
            name = rs.getString("Price");
            System.out.println(name);
        }*/
    }
    catch(ClassNotFoundException | SQLException ex)
    {
        System.out.println(ex);
    }
    }
    
    public static void main(String args[])
    {
        db d1=new db();
        d1.conn();
    }
}

