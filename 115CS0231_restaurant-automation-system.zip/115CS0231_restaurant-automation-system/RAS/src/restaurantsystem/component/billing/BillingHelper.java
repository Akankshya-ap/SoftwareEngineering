
package restaurantsystem.component.billing;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurantsystem.model.Order;
import restaurantsystem.model.OrderLine;
import restaurantsystem.service.ItemService;
/**
 *
 * @author Akankshya
 */
public class BillingHelper {

    private Scanner sc;
    private Scanner scan;
    private String name;
    private String price;
    private String quantity;
    private StringBuilder fullnames;
    private double dPrice;
    private int dQuantity;
    private double multi;
    private PrintWriter pw;
    private Connection con;
    private Statement st;
    private ResultSet rs;
    private PreparedStatement ps;

    public BillingHelper() {
        fullnames = new StringBuilder();
        readFile();
        closeFile();
    }
     public void connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rats","root","");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public StringBuilder getFullNames() {
        return fullnames;
    }

    public String getTotal() {
        connect();
        double totalPrice = 0;

        try{
            st=con.createStatement();
            rs=st.executeQuery("Select price from order");
            price=rs.getString("price");
                totalPrice += Double.parseDouble(price);
                System.out.println(totalPrice);
          
        
           
        } catch (NumberFormatException | SQLException ex) {
            System.out.println(ex);
        }
        return String.valueOf("Total Price is : " + totalPrice);
    }



    private void readFile() {
        connect();
        try{
            st=con.createStatement();
            rs=st.executeQuery("Select * from order");
            while(rs.next())
            {
            String orderInfo[]={rs.getString("no"),rs.getString("name"),rs.getString("quantity"),rs.getString("price")};
                name = orderInfo[1];
                quantity = orderInfo[2];
                price = orderInfo[3];
                fullnames.append(name + " \t" + quantity + "\t" + price + "\n");
                
            }
        } catch (NumberFormatException | SQLException ex) {
            System.out.println(ex);
        }
       
    }

    private void closeFile() {
        scan.close();
    }
}
