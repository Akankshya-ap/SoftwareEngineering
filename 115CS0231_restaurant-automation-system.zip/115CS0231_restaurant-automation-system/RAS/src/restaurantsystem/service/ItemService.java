
package restaurantsystem.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurantsystem.component.item.UpdateItem;
import restaurantsystem.model.Item;
/**
 *
 * @author Akankshya
 */
public class ItemService {

    private Connection con;
    private Statement st;
    private ResultSet rs;
    private PreparedStatement ps;
    public ItemService() {
    }

    public List<Item> getAll() {
        connect();
        List<Item> items = new ArrayList<>();

                try{
            st=con.createStatement();
            rs=st.executeQuery("Select * from item");
            while(rs.next())
            {
            String itemInfo[]={rs.getString("name"),rs.getString("Price"),rs.getString("Quantity")};
           
                Item item = new Item(itemInfo[0], Double.parseDouble(itemInfo[1]),
                        Integer.parseInt(itemInfo[2]));

                items.add(item);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return items;
    }

    public Item getItemByIndex(int index) {
        List<Item> listOfItem = getAll();

        if (listOfItem.size() >= index) {
            return listOfItem.get(index - 1);
        }

        return null;
    }

    public void connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rats","root","");
        } catch (Exception ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void create(Item item) {
        connect();
        try {
            
            ps=con.prepareStatement("INSERT INTO item VALUES(?,?,?)");
            ps.setString(1,item.getName());
            ps.setString(2,String.valueOf( item.getPrice()));
            ps.setString(3,String.valueOf(item.getQuantity()));
            ps.executeUpdate();
            }
        catch (SQLException ex) {
            System.out.println(ex);
        }
    }

   
    public synchronized boolean delete(String name) {

        connect();
        try {
            
            ps=con.prepareStatement("Delete from item where name=?");
            ps.setString(1,name);
            ps.executeUpdate();
            }
        catch (SQLException ex) {
            System.out.println(ex);
        }
      return true;
    }

    public synchronized boolean update(String srcName, Item updatedItem) {
        connect();
        try {
        ps=con.prepareStatement("Update item set name=? Price=? Quantity=? where name=?");
        ps.setString(1,updatedItem.getName());
        ps.setDouble(2,updatedItem.getPrice());
        ps.setInt(3,updatedItem.getQuantity());
        ps.setString(4, srcName);
        ps.executeUpdate();
        }
        catch (SQLException ex) {
            System.out.println(ex);
        }
        return true;
        
    }

    public synchronized void reduceItemQuantityByItemName(String itemName, int reduceNumber) {
        List<Item> itemList = getAll();

        for (int i = 0; i < itemList.size(); i++) {

            Item item = itemList.get(i);

            if (item.getName().equalsIgnoreCase(itemName)) {
                item.setQuantity(Math.max(0, item.getQuantity() - reduceNumber));
                itemList.set(i, item);
            }
        }

        try {
            Files.delete(Paths.get("storage/item.txt"));
        } catch (IOException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }

        try (PrintWriter pw = new PrintWriter(new FileOutputStream("storage/item.txt"))) {
            itemList.forEach(item -> {
                pw.println(item.getName() + "," + item.getPrice() + "," + item.getQuantity());
            });
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
