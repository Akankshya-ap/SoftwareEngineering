/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurantsystem.service;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurantsystem.model.Item;
import java.sql.*;
import restaurantsystem.model.OrderLine;

/**
 *
 * @author Akankshya
 */
public class SalesReport {
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
    private PreparedStatement ps;
    
    public void connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rats","root","");
        } catch (Exception ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public SalesReport() {
    }

    
    public List<OrderLine> getAll() {
        connect();
        List<OrderLine> sales = new ArrayList<>();
        try{
            st=con.createStatement();
            rs=st.executeQuery("Select * from orderLine");
            while(rs.next())
            {
            String orderInfo[]={rs.getString("no"),rs.getString("name"),rs.getString("quantity"),rs.getString("price")};
           
                OrderLine ol = new OrderLine(Integer.parseInt(orderInfo[0]),orderInfo[1],Integer.parseInt(orderInfo[2]), Double.parseDouble(orderInfo[3]));

                sales.add(ol);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        return sales;
    }
    
    
    public OrderLine getorderByIndex(int index) {
        List<OrderLine> listOforder = getAll();

        if (listOforder.size() >= index) {
            return listOforder.get(index - 1);
        }

        return null;
    }
}

    