/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurantsystem.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurantsystem.model.Item;
import java.sql.*;
/**
 *
 * @author Akankshya
 */
public class ingredientservice {
    public ingredientservice()
    {}
        double pricer = 0;
        private Connection con;
        private Statement st;
        private ResultSet rs;
        private PreparedStatement ps;
public void connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rats","root","");
        } catch (Exception ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
public List<Item> getAll() {
        connect();
        List<Item> items = new ArrayList<>();

                try{
            st=con.createStatement();
            rs=st.executeQuery("Select * from item");
            while(rs.next())
            {
            String itemInfo[]={rs.getString("name"),rs.getString("Price"),rs.getString("Quantity")};
           
                Item item = new Item(itemInfo[0], Double.parseDouble(itemInfo[1]),
                        Integer.parseInt(itemInfo[2]));
                if(Integer.parseInt(itemInfo[2])<4)
                {
                    pricer+=Double.parseDouble(itemInfo[1]);
                    items.add(item);
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return items;
    }

public String getPrice()
{
    return String.valueOf(pricer);
    
}
}